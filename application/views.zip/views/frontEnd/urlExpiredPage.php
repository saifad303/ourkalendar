<section id="page-main-content">
    <div class="event-details-padding">
        <!-- ++++++++++++++++++++ Start blank-page ++++++++++++++++++++ -->
        <div class="event-details-heading blank-page">
            <div class="container">
                <h2>This URL has been expired.</h2>
                <a href="<?php echo base_url("Home/forgetPass"); ?>"><button type="button" class="btn">Try again.</button></a>
            </div><!-- /.container -->	
        </div><!-- /.event-details-heading -->
    </div><!-- End /.event-details-padding -->
</section><!-- End #page-main-content -->