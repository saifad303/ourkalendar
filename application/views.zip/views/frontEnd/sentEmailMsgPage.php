<section id="page-main-content">
    <div class="event-details-padding">
        <!-- ++++++++++++++++++++ Start blank-page ++++++++++++++++++++ -->
        <div class="event-details-heading blank-page">
            <div class="container">
                <h2>A confirmation message has been sent to your email.</h2>
            </div><!-- /.container -->	
        </div><!-- /.event-details-heading -->
    </div><!-- End /.event-details-padding -->
</section><!-- End #page-main-content -->