
<link rel="stylesheet" href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/css/styles.min.css">

<!--    <header class="header">
        <p class="text-center">Header Part is here</p>
    </header>-->

    <main class="main container">

        <div class="row">

            <aside class="profile-sidebar">
                <div class="profile-picture">
                    <img src="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/images/profile-photo.jpg" alt="Profile Photo" class="picture">
                </div>
                <div class="profile-info">
                    <h4 class="name">Adriana C. Ocampo Uria</h4>
                    <div class="contact">
                        <div class="info-container">
                            <span class="info"><i class="la la-mobile"></i> 017825814723</span>
                        </div>
                        <div class="info-container">
                            <span class="info"><i class="la la-envelope"></i> <a href="mailto:webmaster@example.com">ariana_oampo@example.com</a></span>
                        </div>
                        <div class="info-container">
                            <span class="info"><i class="la la-map-marker"></i> Some place in Germany</span>
                        </div>
                        <div class="info-container">
                            <span class="info"><i class="la la-internet-explorer"></i> <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#"> www.example.com/domain_name.com</a></span>
                        </div>
                    </div>
                    <div class="message">
                        <button class="btn message-btn"><i class="la la-wechat"></i> Send Messsage</button>
                    </div>
                </div>

                <div class="profile-tabs nav nav-pills" id="profile-details-tab" role="tablist">
                    <a class="tab nav-link active" href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#event"  id="event-tab" data-toggle="pill" role="tab" aria-selected="true">Events</a>
                    <a class="tab nav-link " href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#calender" id="calender-tab" data-toggle="pill" role="tab" aria-selected="false">Calender</a>
                    <a class="tab nav-link " href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#messages" data-toggle="pill" role="tab">Messages</a>
                    <a class="tab nav-link " href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#about" data-toggle="pill" role="tab">About</a>
                </div>
            </aside>

            <div class="profile-details tab-content">

                <div class="tab-pane fade show active" id="event" role="tabpanel" aria-labelledby="event-tab">

                    <div class="page-header">
                        <h2 class="page-header-name">Events</h2>
                    </div>

                    <div class="event-filter">
                        <button class="btn filter active">All</button>
                        <button class="btn filter">Poster By You</button>
                        <button class="btn filter">Poster By Others</button>
                        <button class="btn filter">Calender</button>
                    </div>

                    <ul class="list-unstyled events-list">

                        <li class="events">
                            <div class="date-section">
                                <div class="date-day">22</div>
                                <div class="date-month">Jan,18</div>
                            </div>
                            <div class="details-section">
                                <div class="event-image" style="background-image: url('<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/images/event-1.jpg')"></div>
                                <div class="event-details">
                                    <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#" class="event-name"><h4>The Jimi Hendrix Experience Worldwide Tour</h4></a>
                                    <p class="organizer">Organized By: <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#">Darryl Stephens</a></p>
                                    <p class="short-details">
                                        Lorem ipsum is a pseudo-Latin text used in web design, typography, layout, and printing in place of English to emphasise design elements over content. It's also called placehol
                                    </p>
                                    <div class="time-location">
                                        <span class="detail"><i class="la la-clock-o"></i> Saturday, 10:30 am - 5:30 pm</span>
                                        <span class="detail"><i class="la la-map-marker"></i> Woodstock</span>
                                    </div>
                                </div>
                            </div>
                            <div class="action-section">
                                <div class="cost">$35</div>
                                <button class="btn btn-sm join">Join</button>
                            </div>
                        </li>

                        <li class="events active">
                            <div class="date-section">
                                <div class="date-day">22</div>
                                <div class="date-month">Jan,18</div>
                            </div>
                            <div class="details-section">
                                <div class="event-image" style="background-image: url('<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/images/event-1.jpg')"></div>
                                <div class="event-details">
                                    <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#" class="event-name"><h4>The Jimi Hendrix Experience Worldwide Tour</h4></a>
                                    <p class="organizer">Organized By: <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#">Darryl Stephens</a></p>
                                    <p class="short-details">Welcome! Calling all DMV Producers, Beatmakers, and Artists from all genres! At least once a month we meet at a local DC lounge and listen</p>
                                    <div class="time-location">
                                        <span class="detail"><i class="la la-clock-o"></i> Saturday, 10:30 am - 5:30 pm</span>
                                        <span class="detail"><i class="la la-map-marker"></i> Woodstock</span>
                                    </div>
                                </div>
                            </div>
                            <div class="action-section">
                                <div class="cost">$35</div>
                                <button class="btn btn-sm join" >Going</button>
                            </div>
                        </li>

                        <li class="events">
                            <div class="date-section">
                                <div class="date-day">22</div>
                                <div class="date-month">Jan,18</div>
                            </div>
                            <div class="details-section">
                                <div class="event-image" style="background-image: url('<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/images/event-1.jpg')"></div>
                                <div class="event-details">
                                    <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#" class="event-name"><h4>The Jimi Hendrix Experience Worldwide Tour</h4></a>
                                    <p class="organizer">Organized By: <a href="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/#">Darryl Stephens</a></p>
                                    <p class="short-details">Welcome! Calling all DMV Producers, Beatmakers, and Artists from all genres! At least once a month we meet at a local DC lounge and listen</p>
                                    <div class="time-location">
                                        <span class="detail"><i class="la la-clock-o"></i> Saturday, 10:30 am - 5:30 pm</span>
                                        <span class="detail"><i class="la la-map-marker"></i> Woodstock</span>
                                    </div>
                                </div>
                            </div>
                            <div class="action-section">
                                <div class="cost">$35</div>
                                <button class="btn btn-sm join">Join</button>
                            </div>
                        </li>

                    </ul>


                </div>

                <div class="tab-pane fade" id="calender" role="tabpanel" aria-labelledby="calender-tab">Calender</div>
                <div class="tab-pane fade" id="messages" role="tabpanel" aria-labelledby="messages-tab">Message</div>
                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="settings-tab">About</div>

            </div>

        </div>

    </main>
</html>

<script src="<?php echo base_url(); ?>public/frontEndDesign/userAccPanel/new/js/main.min.js"></script>