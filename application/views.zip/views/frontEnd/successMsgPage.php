<section id="page-main-content">
    <div class="event-details-padding">
        <!-- ++++++++++++++++++++ Start blank-page ++++++++++++++++++++ -->
        <div class="event-details-heading blank-page">
            <div class="container">
                <h1>Your password is successfully changed.</h1>
            </div><!-- /.container -->	
        </div><!-- /.event-details-heading -->
    </div><!-- End /.event-details-padding -->
</section><!-- End #page-main-content -->